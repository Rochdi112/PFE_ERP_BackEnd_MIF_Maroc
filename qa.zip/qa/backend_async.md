# Tâches Async / Redis

## Controls

- Idempotence: To be verified
- Retry/backoff: To be verified
- DLQ: To be verified
- Timeouts: To be verified

## Criteria

- Échecs simulés gérés sans perte: To be verified

## Artifacts

- This report
