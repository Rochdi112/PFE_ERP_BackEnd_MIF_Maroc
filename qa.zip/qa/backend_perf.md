# Performance

## Outils

- Locust/k6 scénarios Auth, CRUD, uploads: Not run

## Cibles

- P95 simples <200 ms: To be verified
- CRUD <500 ms: To be verified
- Erreurs <1%: To be verified

## Artifacts

- This report
- Rapports Locust/k6: To be generated
