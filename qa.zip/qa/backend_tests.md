# Tests & Mutation

## Cmd

- pytest --cov=app --cov-branch: Not run
- mutmut run: Not run

## Criteria

- cov ≥85% lignes: To be verified
- ≥80% branches: To be verified
- mutation ≥60% domaines cœur: To be verified

## Artifacts

- This report
- Rapport mutation: To be generated
