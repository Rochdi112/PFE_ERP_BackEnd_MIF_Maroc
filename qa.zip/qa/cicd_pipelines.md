# CI/CD Pipelines

## BE

- lint/types/tests/coverage/scans/build image: To be verified

## FE

- lint/types/tests/build/Lighthouse: To be verified

## E2E

- environnement éphémère, Playwright: To be verified

## Criteria

- Gates bloquants verts: To be verified

## Artifacts

- This report
