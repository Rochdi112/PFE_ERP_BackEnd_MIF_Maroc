# Domain Auth & Accounts

## Tests

- RBAC {admin,responsable,technicien,client}: To be verified
- MFA optionnelle: To be verified
- Reset MDP: To be verified
- Audit trail: To be verified

## Criteria

- Moindres privilèges respectés: To be verified
- Audit complet: To be verified

## Artifacts

- This report
