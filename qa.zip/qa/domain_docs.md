# Domain Gestion documentaire

## Tests

- Types: To be verified
- Versioning: To be verified
- ACL: To be verified
- Chiffrement AES-Fernet: To be verified
- Antivirus: To be verified

## Criteria

- Accès contrôlé: To be verified
- Intégrité versions: To be verified

## Artifacts

- This report
