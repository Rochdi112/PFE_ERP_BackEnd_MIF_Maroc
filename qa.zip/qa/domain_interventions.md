# Domain Interventions

## Workflow

- Ouverte→Affectée→En cours→Clôturée: To be verified
- Types {préventive, corrective, urgente}: To be verified
- Priorités: To be verified
- SLA: To be verified

## Tests

- Conflits planning: To be verified
- Pièces: To be verified
- Temps passé: To be verified
- Coûts: To be verified

## Criteria

- Transitions valides: To be verified
- Règles SLA appliquées: To be verified

## Artifacts

- This report
