# Domain Planning & Scheduling

## Tests

- Vue M/W: To be verified
- Affectation auto/manuelle: To be verified
- Notifications: To be verified
- Détection conflits: To be verified

## Criteria

- Aucune double-affectation: To be verified
- Rappels délivrés: To be verified

## Artifacts

- This report
