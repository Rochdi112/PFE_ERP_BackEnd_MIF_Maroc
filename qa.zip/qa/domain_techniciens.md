# Domain Techniciens

## Tests

- Compétences: To be verified
- Disponibilité: To be verified
- Charge: To be verified
- Certifications: To be verified

## Criteria

- Affectation respecte compétences et disponibilité: To be verified

## Artifacts

- This report
