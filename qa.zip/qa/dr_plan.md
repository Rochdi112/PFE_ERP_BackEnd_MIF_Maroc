# DR Plan

## Controls

- Sauvegardes chiffrées: To be verified
- RPO≤24h: To be verified
- RTO≤2h: To be verified
- Test de restauration: To be verified

## Artifacts

- This report
