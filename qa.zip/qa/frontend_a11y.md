# Frontend Accessibility

## Cmd

- jest-axe/axe: pnpm run test:axe

Output: Not run

## Criteria

- 0 violation critique: To be verified
- Navigation clavier OK: To be verified
- Contrastes AA: To be verified

## Artifacts

- This report
