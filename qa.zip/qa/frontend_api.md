# Frontend API Integration

## Controls

- Client généré depuis openapi.json (Orval/openapi-typescript): To be verified
- Retry backoff GET idempotents: To be verified
- Gestion refresh JWT avec file d’attente: To be verified
- 401→logout: To be verified
- Erreurs centralisées: To be verified

## Criteria

- Aucune URL en dur: To be verified
- Pas de race condition au refresh: To be verified

## Artifacts

- This report
