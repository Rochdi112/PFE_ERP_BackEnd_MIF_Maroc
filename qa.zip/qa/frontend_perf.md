# Frontend Performance

## Cmd

- pnpm run build: Not run
- Bundle analyzer: Not run
- Lighthouse: Not run

## Cibles

- LCP <2.5 s: To be verified
- CLS <0.1: To be verified
- INP <200 ms: To be verified
- Poids bundle sous budgets: To be verified

## Artifacts

- lighthouse/: Created
- This report
- bundle-stats.json: To be generated
