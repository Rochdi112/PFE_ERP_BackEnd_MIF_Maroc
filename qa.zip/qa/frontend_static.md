# Frontend Static & Dependencies

## Pnpm Install

Command: pnpm i --frozen-lockfile

Output: Not run (pnpm not checked)

## Lint

Command: pnpm run lint

Output: Not run

## Typecheck

Command: pnpm run typecheck

Output: Not run

## Depcheck

Command: pnpm dlx depcheck

Output: Not run

## Criteria

- TS strict propre: To be verified
- Deps orphelines traitées: To be verified

## Artifacts

- This report
