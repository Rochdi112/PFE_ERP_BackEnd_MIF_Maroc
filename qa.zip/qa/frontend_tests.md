# Frontend Tests

## Unitaires/Intégration

- pnpm run test: Not run

## E2E

- Playwright contre backend réel en dev: Not run

## Visuel

- Si besoin: Not run

## Criteria

- FE cov ≥70% lignes: To be verified
- E2E verts sur parcours clés: To be verified

## Artifacts

- playwright-report/: Created
- This report
