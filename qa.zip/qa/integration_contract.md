# Integration Contract

## Process

- Versionner openapi.json: To be verified
- Régénérer client FE à chaque release BE: To be verified

## Tests

- Schemathesis côté provider: Not run
- Pact: Not run

## Criteria

- 0 divergence: To be verified

## Artifacts

- This report
