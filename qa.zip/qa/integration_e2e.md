# Integration E2E

## Stack

- docker compose (Postgres+Redis+BE+Nginx) + FE dev/prod: Not run

## Scénarios

- login→refresh→RBAC, CRUD interventions/équipements/techniciens, planning, documents (upload/download), filtres/pagination, erreurs 4xx/5xx, offline: Not run

## Criteria

- 0 flake: To be verified
- Tous scénarios verts: To be verified

## Artifacts

- This report
- Vidéos Playwright: To be generated
