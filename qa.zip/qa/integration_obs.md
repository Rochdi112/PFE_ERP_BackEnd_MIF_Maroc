# Integration Observability

## Controls

- Propagation trace_id FE→BE: To be verified
- Tableaux latences et erreurs par route: To be verified
- Journaux d’audit: To be verified

## Criteria

- Dashboards lisibles: To be verified
- Alertes testées: To be verified

## Artifacts

- metrics_screens/: Created
- This report
