# Nginx Production

## Controls

- TLS 1.2+: To be verified
- HSTS: To be verified
- Compression: To be verified
- Cache static: To be verified

## Artifacts

- This report
