# Performance DB

## Controls

- Plans EXPLAIN: To be verified
- Index partiels/couvrants: To be verified
- Autovacuum: To be verified
- Partitionnement si volumes: To be verified

## Artifacts

- This report
