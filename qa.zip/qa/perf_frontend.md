# Performance Frontend

## Outils

- Lighthouse: Not run
- WebPageTest: Not run

## Criteria

- LCP/CLS/INP OK: To be verified

## Artifacts

- This report
