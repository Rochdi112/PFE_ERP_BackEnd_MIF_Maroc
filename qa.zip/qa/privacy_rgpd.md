# Privacy & RGPD

## Controls

- Classification PII: To be verified
- Minimisation: To be verified
- Droits RGPD: To be verified
- Bannières consentement: To be verified
- DPA: To be verified

## Criteria

- Conformité déclarée et testée: To be verified

## Artifacts

- This report
