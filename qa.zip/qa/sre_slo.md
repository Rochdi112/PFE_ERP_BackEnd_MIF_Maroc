# SRE SLO & Alerting

## Controls

- SLO latence/erreurs: To be verified
- Alertes Prometheus: To be verified
- Procédures incident/postmortem: To be verified

## Artifacts

- This report
